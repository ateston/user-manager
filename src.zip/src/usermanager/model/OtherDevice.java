package usermanager.model;

public class OtherDevice extends Device {

}
