package usermanager.bridge;

public interface IPersistanceBridge {

}
