package usermanager.bridge;

public class CommBridge implements ICommBridge {

}
