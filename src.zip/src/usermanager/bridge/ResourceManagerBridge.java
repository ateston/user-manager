package usermanager.bridge;

public class ResourceManagerBridge implements IResourceManagerBridge {

}
