package usermanager.bridge;

public interface IResourceManagerBridge {

}
