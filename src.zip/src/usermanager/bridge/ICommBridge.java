package usermanager.bridge;

public interface ICommBridge {

}
