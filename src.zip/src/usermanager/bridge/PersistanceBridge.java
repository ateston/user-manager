package usermanager.bridge;

public class PersistanceBridge implements IPersistanceBridge {

}
