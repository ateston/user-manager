package usermanager.util;

public class Status {
    
    public static final int CONNECTED = 0;
    public static final int CONNECTING = 1;
    public static final int DISCONNECTED = 2;
    public static final int UPDATED = 3;
    public static final int UPDATING = 4;
    
}
